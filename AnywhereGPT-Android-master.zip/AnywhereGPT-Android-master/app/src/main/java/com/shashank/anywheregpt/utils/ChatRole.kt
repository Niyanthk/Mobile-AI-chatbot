package com.shashank.anywheregpt.utils

enum class ChatRole {
    SYSTEM, USER, ASSISTANT
}