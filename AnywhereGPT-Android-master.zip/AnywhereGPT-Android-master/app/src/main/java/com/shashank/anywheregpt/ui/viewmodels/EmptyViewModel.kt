package com.shashank.anywheregpt.ui.viewmodels

import androidx.lifecycle.ViewModel

class EmptyViewModel : ViewModel()